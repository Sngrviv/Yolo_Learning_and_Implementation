# Basketball Players Detection > 2025-10-09 12:45pm
https://universe.roboflow.com/vivek-wnq8p/basketball-players-detection-fhjpk

Provided by a Roboflow user
License: MIT

